To use this pack, you'll need the connected resource pack, along with the main RWMC resource pack. To get the textures to work
you also need to install Polytone, it's a mod that allows me to bypass some of Minecraft's limitations.

To teleport to the dimension use: /execute in rain_world:rain_dimension run tp @s ~ ~ ~

Recommended to play in creative mode! There are no plans to make the dimension compatible with survival, though
all the resources you need are technically there. Once creatures are coded in, I'll add them and item spawns to
make the dimension compatible with adventure mode.